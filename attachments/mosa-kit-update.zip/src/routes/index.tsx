import { useMemo, useState } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { Canvas } from "@react-three/fiber";
import { ContactShadows, OrbitControls } from "@react-three/drei";
import * as THREE from "three";
import { KITS, defaultId, kitById, kitsByBand, type KitBand } from "@/lib/mosa/kits";
import {
  GROUPS,
  defaultHiddenSlots,
  familyById,
  isFamilyVisible,
  slotsFor,
  toggleFamily,
} from "@/lib/mosa/parts";
import { HangarLights, MosaFrame } from "@/lib/mosa/frame";

export const Route = createFileRoute("/")({
  ssr: false,
  component: Home,
});

const BANDS: KitBand[] = ["SS", "SR", "RS", "RR"];

function Home() {
  const [kitId, setKitId] = useState(defaultId);
  const [groupId, setGroupId] = useState("Head");
  const [familyId, setFamilyId] = useState("helm");
  const [hidden, setHidden] = useState<Set<string>>(() => defaultHiddenSlots());
  const [explode, setExplode] = useState(false);
  const [band, setBand] = useState<KitBand>("RR");

  const kit = useMemo(() => kitById(kitId), [kitId]);
  const group = GROUPS.find((g) => g.id === groupId) ?? GROUPS[0]!;
  const family = familyById(familyId);
  const bandKits = kitsByBand(band);

  function pickKit(id: string) {
    const next = kitById(id);
    setKitId(next.id);
    setBand(next.band);
  }

  function hideSelected() {
    setHidden((h) => {
      const next = new Set(h);
      for (const slot of slotsFor(groupId, familyId)) next.add(slot);
      return next;
    });
  }

  function resetParts() {
    setHidden(defaultHiddenSlots());
  }

  return (
    <main className="relative flex h-svh min-h-0 flex-col overflow-hidden bg-hangar text-fg">
      <header className="flex shrink-0 items-center justify-between gap-4 border-b border-line px-4 py-3">
        <div className="min-w-0">
          <h1 className="text-sm font-semibold tracking-[0.22em]">MOSA</h1>
          <p className="truncate text-xs text-muted">
            Modular Omni-Support Automata / Mimetic Operating System Architecture
          </p>
        </div>
        <div className="flex items-center gap-3">
          <label className="hidden text-xs text-muted sm:block">Kit</label>
          <select
            className="max-w-40 rounded-md border border-line bg-panel-2 px-2 py-1 font-mono text-xs text-fg"
            value={kit.id}
            onChange={(e) => pickKit(e.target.value)}
            aria-label="Kit"
          >
            {KITS.map((k) => (
              <option key={k.id} value={k.id}>
                {k.id}
              </option>
            ))}
          </select>
          <button
            type="button"
            onClick={() => setExplode((v) => !v)}
            className={`rounded-md border px-3 py-1 text-xs ${
              explode ? "border-kit bg-kit text-hangar" : "border-line bg-panel-2 text-fg"
            }`}
          >
            Explode
          </button>
        </div>
      </header>

      <div className="flex gap-1 overflow-x-auto border-b border-line p-2 md:hidden">
        {GROUPS.map((g) => (
          <button
            key={g.id}
            type="button"
            onClick={() => {
              setGroupId(g.id);
              setFamilyId(g.families[0]!);
            }}
            className={`shrink-0 rounded-sm px-2 py-1 text-[11px] ${
              g.id === groupId ? "bg-kit text-hangar" : "bg-panel-2 text-muted"
            }`}
          >
            {g.label}
          </button>
        ))}
      </div>

      <div className="flex min-h-0 flex-1">
        <aside className="hangar-scroll hidden w-72 shrink-0 overflow-y-auto border-r border-line bg-panel md:flex md:flex-col">
          <div className="border-b border-line px-3 py-2 text-[11px] tracking-[0.18em] text-muted uppercase">
            Parts
          </div>
          <div className="flex flex-wrap gap-1 border-b border-line p-2">
            {GROUPS.map((g) => (
              <button
                key={g.id}
                type="button"
                onClick={() => {
                  setGroupId(g.id);
                  setFamilyId(g.families[0]!);
                }}
                className={`rounded-sm px-2 py-1 text-[11px] ${
                  g.id === groupId ? "bg-kit text-hangar" : "bg-panel-2 text-muted hover:text-fg"
                }`}
              >
                {g.label}
              </button>
            ))}
          </div>
          <ul className="flex-1 p-1">
            {group.families.map((id) => {
              const fam = familyById(id);
              if (!fam) return null;
              const on = isFamilyVisible(hidden, group.id, id);
              return (
                <li key={id}>
                  <button
                    type="button"
                    onClick={() => setFamilyId(id)}
                    className={`flex w-full items-center justify-between gap-2 rounded-sm px-3 py-2 text-left text-sm ${
                      familyId === id ? "bg-panel-2" : "hover:bg-panel-2/60"
                    }`}
                  >
                    <span>
                      <span className="block">{fam.label}</span>
                      <span className="font-mono text-[10px] text-muted">
                        {kit.id} · {fam.status}
                      </span>
                    </span>
                    <span
                      role="button"
                      tabIndex={0}
                      onClick={(ev) => {
                        ev.stopPropagation();
                        setHidden((h) => toggleFamily(h, group.id, id));
                      }}
                      onKeyDown={(ev) => {
                        if (ev.key === "Enter" || ev.key === " ") {
                          ev.preventDefault();
                          ev.stopPropagation();
                          setHidden((h) => toggleFamily(h, group.id, id));
                        }
                      }}
                      className={`text-[10px] tracking-wide uppercase ${on ? "text-accent" : "text-muted"}`}
                    >
                      {on ? "On" : "Hide"}
                    </span>
                  </button>
                </li>
              );
            })}
          </ul>
          <div className="flex gap-2 border-t border-line p-3">
            <button
              type="button"
              onClick={hideSelected}
              className="flex-1 rounded-md border border-line bg-panel-2 py-2 text-xs"
            >
              Hide
            </button>
            <button
              type="button"
              onClick={resetParts}
              className="flex-1 rounded-md border border-line bg-panel-2 py-2 text-xs"
            >
              Default
            </button>
          </div>
        </aside>

        <section className="relative min-w-0 flex-1 bg-hangar">
          <Canvas
            className="h-full w-full"
            shadows
            dpr={[1, 2]}
            gl={{ antialias: true, powerPreference: "high-performance" }}
            camera={{ position: [2.6, 1.45, 3.4], fov: 32 }}
            onCreated={({ gl }) => {
              gl.toneMapping = THREE.ACESFilmicToneMapping;
              gl.toneMappingExposure = 1.2;
              gl.shadowMap.type = THREE.PCFSoftShadowMap;
              gl.outputColorSpace = THREE.SRGBColorSpace;
            }}
          >
            <color attach="background" args={["#111118"]} />
            <HangarLights />
            <MosaFrame key={kit.id} kit={kit} hidden={hidden} explode={explode ? 1 : 0} />
            <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, 0, 0]} receiveShadow>
              <planeGeometry args={[20, 20]} />
              <meshStandardMaterial color="#14141c" roughness={0.9} metalness={0} />
            </mesh>
            <gridHelper args={[12, 24, "#2a2a34", "#1c1c24"]} position={[0, 0.001, 0]} />
            <ContactShadows position={[0, 0.002, 0]} opacity={0.45} scale={8} blur={2.2} far={4} />
            <OrbitControls
              makeDefault
              enableDamping
              target={[0, 0.95, 0]}
              minDistance={1.4}
              maxDistance={8}
              maxPolarAngle={Math.PI / 2 - 0.04}
            />
          </Canvas>
          <p className="pointer-events-none absolute bottom-4 left-1/2 -translate-x-1/2 text-[11px] tracking-[0.16em] text-muted uppercase">
            Drag to orbit
          </p>
        </section>

        <aside className="hangar-scroll hidden w-80 shrink-0 overflow-y-auto border-l border-line bg-panel lg:flex lg:flex-col">
          <div className="border-b border-line px-4 py-3">
            <div className="text-[11px] tracking-[0.18em] text-muted uppercase">Details</div>
            <h2 className="mt-1 text-lg">{family?.label ?? "Helm"}</h2>
            <p className="font-mono text-xs text-kit">{kit.id}</p>
          </div>
          <div className="border-b border-line px-4 py-3 font-mono text-[11px] text-muted">
            <div>band {kit.band}</div>
            <div>segments {kit.segments}</div>
            <div>chamfer {kit.chamfer}</div>
            <div>spike {kit.spike}</div>
            <div>prim {kit.prim}</div>
          </div>
          <div className="px-3 py-2 text-[11px] tracking-[0.18em] text-muted uppercase">ID</div>
          <div className="flex gap-1 px-3">
            {BANDS.map((b) => (
              <button
                key={b}
                type="button"
                onClick={() => setBand(b)}
                className={`flex-1 rounded-sm py-1 font-mono text-[11px] ${
                  band === b ? "bg-kit text-hangar" : "bg-panel-2 text-muted"
                }`}
              >
                {b}
              </button>
            ))}
          </div>
          <div className="grid grid-cols-5 gap-1 p-3">
            {bandKits.map((k) => (
              <button
                key={k.id}
                type="button"
                onClick={() => pickKit(k.id)}
                className={`rounded-sm px-1 py-2 font-mono text-[9px] leading-tight ${
                  k.id === kit.id ? "bg-kit text-hangar" : "bg-panel-2 text-muted hover:text-fg"
                }`}
                title={`${k.id} segs ${k.segments} chamfer ${k.chamfer} spike ${k.spike}`}
              >
                {k.id}
              </button>
            ))}
          </div>
          <p className="px-4 pb-4 text-[11px] leading-relaxed text-muted">
            One parametric frame per kit. Builder parts are slot families on that
            frame — not 100 imported meshes. Head helm/visor stay RRE-080 forms
            (sphere dome, disc visor, crest none).
          </p>
        </aside>
      </div>
    </main>
  );
}
