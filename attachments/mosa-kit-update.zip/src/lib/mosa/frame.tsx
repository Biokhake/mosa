import { useMemo } from "react";
import { DoubleSide } from "three";
import type { Kit } from "./kits";

type FrameProps = {
  kit: Kit;
  hidden: ReadonlySet<string>;
  explode: number;
};

const PLA = {
  SS: "#dfe3e8",
  SR: "#d4d0c6",
  RS: "#d7d2c8",
  RR: "#d9d0c4",
} as const;

function radial(kit: Kit): number {
  if (kit.prim === "prism4") return 4;
  if (kit.prim === "prism6") return 6;
  if (kit.prim === "cone") return 4;
  if (kit.prim === "box-chamfer") return 8;
  if (kit.prim === "sphere" || kit.prim === "high-seg") return Math.max(16, kit.segments);
  return Math.max(6, kit.segments);
}

function limbTaper(kit: Kit): [number, number] {
  if (kit.prim === "cone") return [0.42, 1];
  if (kit.prim === "mix") return [0.78, 1];
  if (kit.prim === "sphere" || kit.prim === "high-seg") return [0.92, 1];
  return [1, 1];
}

function PlaMat({ kit, color }: { kit: Kit; color?: string }) {
  return (
    <meshStandardMaterial
      color={color ?? PLA[kit.band]}
      roughness={0.55}
      metalness={0}
      envMapIntensity={0.3}
    />
  );
}

function BayMat() {
  return <meshStandardMaterial color="#2a2a30" roughness={0.4} metalness={0.1} />;
}

function GearMat() {
  return <meshStandardMaterial color="#9aa0a8" roughness={0.3} metalness={0.7} />;
}

function FrameMat() {
  return <meshStandardMaterial color="#3a3a42" roughness={0.45} metalness={0.12} />;
}

/** MG90S-class visual only: small box + horn. Bay is not buried. */
function Servo({
  position,
  rotation = [0, 0, 0],
}: {
  position: [number, number, number];
  rotation?: [number, number, number];
}) {
  return (
    <group position={position} rotation={rotation}>
      <mesh castShadow>
        <boxGeometry args={[0.09, 0.046, 0.08]} />
        <BayMat />
      </mesh>
      <mesh position={[0.055, 0, 0]} castShadow>
        <boxGeometry args={[0.02, 0.01, 0.08]} />
        <BayMat />
      </mesh>
      <mesh position={[-0.055, 0, 0]} castShadow>
        <boxGeometry args={[0.02, 0.01, 0.08]} />
        <BayMat />
      </mesh>
      <mesh position={[0, 0.028, 0]} rotation={[Math.PI / 2, 0, 0]} castShadow>
        <cylinderGeometry args={[0.016, 0.016, 0.01, 8]} />
        <GearMat />
      </mesh>
      <mesh position={[0.02, 0.028, 0]} castShadow>
        <boxGeometry args={[0.038, 0.006, 0.012]} />
        <GearMat />
      </mesh>
    </group>
  );
}

function Spike({ kit, position, rotation, scale = 1 }: {
  kit: Kit;
  position: [number, number, number];
  rotation?: [number, number, number];
  scale?: number;
}) {
  if (kit.spike < 0.05) return null;
  const h = 0.1 + kit.spike * 0.16;
  const r = 0.018 + kit.spike * 0.02;
  const segs = kit.prim === "prism6" ? 6 : 4;
  return (
    <mesh position={position} rotation={rotation} scale={scale} castShadow>
      <coneGeometry args={[r, h, segs]} />
      <PlaMat kit={kit} />
    </mesh>
  );
}

/** Cutaway panel (ROM) over a thin frame rod — not a full armor statue. */
function Limb({
  kit,
  length,
  radius,
  visible,
}: {
  kit: Kit;
  length: number;
  radius: number;
  visible: boolean;
}) {
  if (!visible) return null;
  const segs = radial(kit);
  const [top, bot] = limbTaper(kit);
  const wrap = kit.band === "RR" ? Math.PI * 1.25 : Math.PI * 0.95;
  return (
    <group>
      <mesh castShadow>
        <cylinderGeometry args={[radius * 0.2, radius * 0.2, length * 0.92, 6]} />
        <FrameMat />
      </mesh>
      <mesh rotation={[0, Math.PI * 0.12, 0]} castShadow>
        <cylinderGeometry
          args={[radius * top, radius * bot, length, segs, 1, false, 0.2, wrap]}
        />
        <meshStandardMaterial
          color={PLA[kit.band]}
          roughness={0.55}
          metalness={0}
          envMapIntensity={0.3}
          side={DoubleSide}
        />
      </mesh>
    </group>
  );
}

function Mass({
  kit,
  kind,
  w,
  h,
  d,
}: {
  kit: Kit;
  kind: "torso" | "joint" | "plate" | "dome";
  w: number;
  h: number;
  d: number;
}) {
  const segs = radial(kit);
  const chamferRot = kit.chamfer > 0 ? Math.PI / 8 : 0;
  const zScale = kit.chamfer > 0 ? 1 - kit.chamfer * 0.4 : 1;

  if (kind === "dome" || kit.prim === "sphere" || kit.prim === "high-seg") {
    const r = Math.max(w, h, d) / 2;
    return (
      <mesh castShadow receiveShadow scale={[w / (r * 2), h / (r * 2), d / (r * 2)]}>
        <sphereGeometry args={[r, segs, Math.max(10, Math.round(segs * 0.6))]} />
        <PlaMat kit={kit} />
      </mesh>
    );
  }

  if (kit.prim === "prism4" && kind !== "joint") {
    return (
      <mesh castShadow receiveShadow>
        <boxGeometry args={[w, h, d]} />
        <PlaMat kit={kit} />
      </mesh>
    );
  }

  if (kit.prim === "cone" && kind === "torso") {
    return (
      <mesh castShadow receiveShadow>
        <cylinderGeometry args={[w * 0.28, w * 0.52, h, 4]} />
        <PlaMat kit={kit} />
      </mesh>
    );
  }

  return (
    <mesh
      castShadow
      receiveShadow
      rotation={[0, chamferRot, 0]}
      scale={[1, 1, zScale]}
    >
      <cylinderGeometry args={[w / 2, w / 2, h, segs]} />
      <PlaMat kit={kit} />
    </mesh>
  );
}

function shown(hidden: ReadonlySet<string>, slot: string) {
  return !hidden.has(slot);
}

function Arm({
  kit,
  hidden,
  side,
}: {
  kit: Kit;
  hidden: ReadonlySet<string>;
  side: "L" | "R";
}) {
  const s = side === "R" ? 1 : -1;
  const sh = `shoulder${side}`;
  const up = `upper${side}`;
  const el = `elbow${side}`;
  const fo = `forearm${side}`;
  const va = `vambrace${side}`;
  const ha = `hand${side}`;
  const we = `weapon${side}`;
  const r = kit.band === "RR" ? 0.055 : 0.05;
  return (
    <group position={[s * 0.34, 1.36, 0]}>
      {shown(hidden, sh) && (
        <group>
          {kit.prim === "sphere" || kit.prim === "high-seg" ? (
            <mesh castShadow>
              <sphereGeometry args={[0.09, radial(kit), radial(kit)]} />
              <PlaMat kit={kit} />
            </mesh>
          ) : kit.prim === "cone" ? (
            <mesh rotation={[0, 0, -s * Math.PI / 2]} castShadow>
              <coneGeometry args={[0.09, 0.16, 4]} />
              <PlaMat kit={kit} />
            </mesh>
          ) : (
            <group rotation={[0, kit.chamfer > 0 ? Math.PI / 8 : 0, 0]}>
              <Mass kit={kit} kind="joint" w={0.16} h={0.12} d={0.14} />
            </group>
          )}
          <Spike kit={kit} position={[s * 0.08, 0.08, 0]} rotation={[0, 0, -s * 0.4]} />
        </group>
      )}
      {shown(hidden, sh) && (
        <Servo position={[s * 0.02, 0, 0]} rotation={[0, 0, s * 0.2]} />
      )}
      <group position={[s * 0.02, -0.18, 0]}>
        <Limb kit={kit} length={0.28} radius={r} visible={shown(hidden, up)} />
      </group>
      <group position={[s * 0.02, -0.36, 0]}>
        {shown(hidden, el) && (
          <mesh castShadow>
            <sphereGeometry args={[0.045, Math.max(8, radial(kit) / 2), 8]} />
            <PlaMat kit={kit} color="#c8c2b8" />
          </mesh>
        )}
        {shown(hidden, el) && (
          <Servo position={[0.02, 0, 0]} rotation={[0, Math.PI / 2, 0]} />
        )}
      </group>
      <group position={[s * 0.02, -0.54, 0]}>
        <Limb kit={kit} length={0.26} radius={r * 0.92} visible={shown(hidden, fo)} />
        {shown(hidden, va) && (
          <mesh position={[0, 0.02, 0.03]} castShadow>
            <boxGeometry args={[0.07, 0.16, 0.02]} />
            <PlaMat kit={kit} />
          </mesh>
        )}
      </group>
      {shown(hidden, ha) && (
        <mesh position={[s * 0.02, -0.7, 0]} rotation={[Math.PI, 0, 0]} castShadow>
          <coneGeometry args={[0.028, 0.08, kit.band === "RR" ? 10 : 4]} />
          <PlaMat kit={kit} />
        </mesh>
      )}
      {shown(hidden, we) && (
        <mesh position={[s * 0.08, -0.72, 0.12]} rotation={[0.5, 0, 0]} castShadow>
          <boxGeometry args={[0.03, 0.03, 0.42]} />
          <meshStandardMaterial color="#4a4a52" roughness={0.4} metalness={0.2} />
        </mesh>
      )}
    </group>
  );
}

function Leg({
  kit,
  hidden,
  side,
}: {
  kit: Kit;
  hidden: ReadonlySet<string>;
  side: "L" | "R";
}) {
  const s = side === "R" ? 1 : -1;
  const r = kit.band === "RR" ? 0.062 : 0.055;
  return (
    <group position={[s * 0.12, 0.86, 0]}>
      {shown(hidden, `hip${side}`) && (
        <mesh castShadow>
          <sphereGeometry args={[0.055, Math.max(8, radial(kit) / 2), 8]} />
          <PlaMat kit={kit} />
        </mesh>
      )}
      <group position={[0, -0.2, 0]}>
        <Limb kit={kit} length={0.32} radius={r} visible={shown(hidden, `thigh${side}`)} />
      </group>
      <group position={[0, -0.4, 0]}>
        {shown(hidden, `knee${side}`) && (
          <mesh castShadow>
            <sphereGeometry args={[0.048, Math.max(8, radial(kit) / 2), 8]} />
            <PlaMat kit={kit} color="#c8c2b8" />
          </mesh>
        )}
        {shown(hidden, `knee${side}`) && (
          <Servo position={[0.02, 0, 0]} rotation={[0, Math.PI / 2, 0]} />
        )}
        <Spike kit={kit} position={[0, 0.02, 0.06]} rotation={[0.6, 0, 0]} />
      </group>
      <group position={[0, -0.6, 0]}>
        <Limb kit={kit} length={0.32} radius={r * 0.9} visible={shown(hidden, `shin${side}`)} />
      </group>
      <group position={[0, -0.78, 0.02]}>
        {shown(hidden, `ankle${side}`) && (
          <mesh castShadow>
            <sphereGeometry args={[0.04, 8, 8]} />
            <PlaMat kit={kit} />
          </mesh>
        )}
      </group>
      {shown(hidden, `foot${side}`) && (
        <mesh position={[0, -0.88, 0.04]} castShadow receiveShadow>
          {kit.band === "RR" || kit.prim === "mix" ? (
            <boxGeometry args={[0.09, 0.035, 0.16]} />
          ) : (
            <boxGeometry args={[0.08, 0.03, 0.18]} />
          )}
          <PlaMat kit={kit} />
        </mesh>
      )}
    </group>
  );
}

export function MosaFrame({ kit, hidden, explode }: FrameProps) {
  const e = explode;
  const segs = radial(kit);

  const head = useMemo(
    () => (
      <group>
        {/* Locked RRE-080 head forms: sphere dome, disc visor, crest none. */}
        {shown(hidden, "helm") && (
          <mesh position={[0, 0.06, 0]} scale={[1, 0.9, 0.95]} castShadow>
            <sphereGeometry args={[0.15, 24, 16]} />
            <PlaMat kit={kit} />
          </mesh>
        )}
        {shown(hidden, "visor") && (
          <group>
            <mesh position={[0, 0.03, 0.12]} rotation={[Math.PI / 2, 0, 0]} castShadow>
              <cylinderGeometry args={[0.1, 0.1, 0.028, 24]} />
              <meshStandardMaterial color="#1c1c22" roughness={0.35} metalness={0.15} />
            </mesh>
            <mesh position={[0, 0.03, 0.136]}>
              <boxGeometry args={[0.14, 0.032, 0.008]} />
              <meshStandardMaterial
                color="#6ec8dc"
                emissive="#1a5a70"
                emissiveIntensity={0.45}
                roughness={0.25}
                metalness={0.2}
              />
            </mesh>
          </group>
        )}
        {shown(hidden, "collar") && (
          <mesh position={[0, -0.1, 0]} rotation={[Math.PI / 2, 0, 0]} castShadow>
            <torusGeometry args={[0.08, 0.018, 8, Math.max(10, segs)]} />
            <PlaMat kit={kit} />
          </mesh>
        )}
        {shown(hidden, "earL") && (
          <mesh position={[-0.14, 0.04, 0]} castShadow>
            <boxGeometry args={[0.03, 0.06, 0.04]} />
            <PlaMat kit={kit} />
          </mesh>
        )}
        {shown(hidden, "earR") && (
          <mesh position={[0.14, 0.04, 0]} castShadow>
            <boxGeometry args={[0.03, 0.06, 0.04]} />
            <PlaMat kit={kit} />
          </mesh>
        )}
        {shown(hidden, "antennaL") && (
          <mesh position={[-0.06, 0.2, 0]} castShadow>
            <cylinderGeometry args={[0.008, 0.008, 0.12, 6]} />
            <PlaMat kit={kit} />
          </mesh>
        )}
        {shown(hidden, "antennaR") && (
          <mesh position={[0.06, 0.2, 0]} castShadow>
            <cylinderGeometry args={[0.008, 0.008, 0.12, 6]} />
            <PlaMat kit={kit} />
          </mesh>
        )}
      </group>
    ),
    [kit, hidden, segs],
  );

  return (
    <group>
      <group position={[0, 1.58 + e * 0.38, 0]}>{head}</group>

      <group position={[0, 1.18 + e * 0.1, 0]}>
        {shown(hidden, "chestCore") && (
          <Mass kit={kit} kind="torso" w={0.42} h={0.36} d={0.24} />
        )}
        {shown(hidden, "cockpit") && (
          <mesh position={[0, 0.02, 0.13]}>
            <boxGeometry args={[0.1, 0.08, 0.012]} />
            <meshStandardMaterial
              color="#c43a32"
              emissive="#6a1410"
              emissiveIntensity={0.35}
              roughness={0.4}
              metalness={0.1}
            />
          </mesh>
        )}
        {shown(hidden, "pecL") && (
          <mesh position={[-0.1, 0.06, 0.12]} castShadow>
            <boxGeometry args={[0.14, 0.1, 0.04]} />
            <PlaMat kit={kit} />
          </mesh>
        )}
        {shown(hidden, "pecR") && (
          <mesh position={[0.1, 0.06, 0.12]} castShadow>
            <boxGeometry args={[0.14, 0.1, 0.04]} />
            <PlaMat kit={kit} />
          </mesh>
        )}
        {shown(hidden, "abdomen") && (
          <mesh position={[0, -0.22, 0]} castShadow>
            <boxGeometry args={[0.22, 0.12, 0.16]} />
            <PlaMat kit={kit} />
          </mesh>
        )}
      </group>

      <group position={[0, 0.88 - e * 0.08, 0]}>
        {shown(hidden, "pelvis") && (
          <Mass kit={kit} kind="torso" w={0.28} h={0.14} d={0.18} />
        )}
        {shown(hidden, "skirtF") && (
          <mesh position={[0, -0.08, 0.08]} rotation={[0.25, 0, 0]} castShadow>
            <boxGeometry args={[0.16, 0.1, 0.03]} />
            <PlaMat kit={kit} />
          </mesh>
        )}
        {shown(hidden, "skirtB") && (
          <mesh position={[0, -0.08, -0.08]} rotation={[-0.25, 0, 0]} castShadow>
            <boxGeometry args={[0.16, 0.1, 0.03]} />
            <PlaMat kit={kit} />
          </mesh>
        )}
        {shown(hidden, "skirtL") && (
          <mesh position={[-0.12, -0.08, 0]} rotation={[0, 0, 0.3]} castShadow>
            <boxGeometry args={[0.03, 0.1, 0.12]} />
            <PlaMat kit={kit} />
          </mesh>
        )}
        {shown(hidden, "skirtR") && (
          <mesh position={[0.12, -0.08, 0]} rotation={[0, 0, -0.3]} castShadow>
            <boxGeometry args={[0.03, 0.1, 0.12]} />
            <PlaMat kit={kit} />
          </mesh>
        )}
      </group>

      <group position={[e * 0.55, e * 0.05, 0]}>
        <Arm kit={kit} hidden={hidden} side="R" />
      </group>
      <group position={[-e * 0.55, e * 0.05, 0]}>
        <Arm kit={kit} hidden={hidden} side="L" />
      </group>

      <group position={[e * 0.22, -e * 0.42, 0]}>
        <Leg kit={kit} hidden={hidden} side="R" />
      </group>
      <group position={[-e * 0.22, -e * 0.42, 0]}>
        <Leg kit={kit} hidden={hidden} side="L" />
      </group>

      <group position={[0, 1.2 + e * 0.06, -0.16 - e * 0.45]}>
        {shown(hidden, "pack") && (
          <mesh position={[0, 0, -0.08]} castShadow>
            {kit.band === "RR" ? (
              <boxGeometry args={[0.22, 0.22, 0.1]} />
            ) : (
              <boxGeometry args={[0.2, 0.24, 0.12]} />
            )}
            <PlaMat kit={kit} />
          </mesh>
        )}
        {shown(hidden, "thrusterL") && (
          <mesh position={[-0.08, -0.08, -0.16]} rotation={[Math.PI / 2, 0, 0]} castShadow>
            <cylinderGeometry args={[0.03, 0.04, 0.1, segs]} />
            <meshStandardMaterial color="#3a3a42" roughness={0.4} metalness={0.2} />
          </mesh>
        )}
        {shown(hidden, "thrusterR") && (
          <mesh position={[0.08, -0.08, -0.16]} rotation={[Math.PI / 2, 0, 0]} castShadow>
            <cylinderGeometry args={[0.03, 0.04, 0.1, segs]} />
            <meshStandardMaterial color="#3a3a42" roughness={0.4} metalness={0.2} />
          </mesh>
        )}
        {shown(hidden, "binderL") && (
          <mesh position={[-0.16, 0.04, -0.04]} rotation={[0.15, 0.4, 0]} castShadow>
            <boxGeometry args={[0.04, 0.28, 0.12]} />
            <PlaMat kit={kit} />
          </mesh>
        )}
        {shown(hidden, "binderR") && (
          <mesh position={[0.16, 0.04, -0.04]} rotation={[0.15, -0.4, 0]} castShadow>
            <boxGeometry args={[0.04, 0.28, 0.12]} />
            <PlaMat kit={kit} />
          </mesh>
        )}
        {shown(hidden, "stabilizer") && (
          <mesh position={[0, -0.16, -0.1]} castShadow>
            <boxGeometry args={[0.08, 0.04, 0.16]} />
            <PlaMat kit={kit} />
          </mesh>
        )}
        <Spike kit={kit} position={[0, 0.16, -0.1]} />
      </group>

      {shown(hidden, "shield") && (
        <mesh position={[0.55 + e * 0.75, 0.9, 0.1]} rotation={[0, 0.4, 0.15]} castShadow>
          <cylinderGeometry args={[0.16, 0.16, 0.025, segs]} />
          <PlaMat kit={kit} />
        </mesh>
      )}

      {shown(hidden, "extra1") && (
        <group position={[0.18, 0.92 - e * 0.1, 0.12 + e * 0.25]}>
          <mesh castShadow>
            <boxGeometry args={[0.06, 0.05, 0.04]} />
            <PlaMat kit={kit} />
          </mesh>
        </group>
      )}
    </group>
  );
}

export function HangarLights() {
  return (
    <>
      <ambientLight color={0x404060} intensity={0.3} />
      <directionalLight
        color={0xffeedd}
        intensity={2.5}
        position={[4, 8, 5]}
        castShadow
        shadow-mapSize-width={2048}
        shadow-mapSize-height={2048}
        shadow-bias={-0.001}
        shadow-normalBias={0.02}
      />
      <directionalLight color={0x4488ff} intensity={0.8} position={[-4, 3, -2]} />
      <directionalLight color={0xffaa55} intensity={0.5} position={[-2, 2, 4]} />
    </>
  );
}
