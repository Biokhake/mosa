/** MOSA frame grammar: SSA-001..RRZ-100. Four bands, skip-letter mids. */

export type KitBand = "SS" | "SR" | "RS" | "RR";

export type KitPrim =
  | "prism4"
  | "prism6"
  | "cone"
  | "box-chamfer"
  | "mix"
  | "sphere"
  | "high-seg";

export type Kit = {
  id: string;
  band: KitBand;
  n: number;
  segments: number;
  chamfer: number;
  spike: number;
  prim: KitPrim;
};

export const defaultId = "RRE-080";

const ALPHA = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";

const BANDS: {
  code: KitBand;
  start: number;
  skip: string;
  segs: [number, number];
  chamfer: [number, number];
  spike: [number, number];
  prims: KitPrim[];
}[] = [
  {
    code: "SS",
    start: 1,
    skip: "S",
    segs: [4, 6],
    chamfer: [0, 0],
    spike: [0.86, 1],
    prims: ["prism4", "prism6", "cone"],
  },
  {
    code: "SR",
    start: 26,
    skip: "S",
    segs: [7, 10],
    chamfer: [0.22, 0.46],
    spike: [0.06, 0.2],
    prims: ["box-chamfer"],
  },
  {
    code: "RS",
    start: 51,
    skip: "R",
    segs: [11, 18],
    chamfer: [0.1, 0.28],
    spike: [0.28, 0.5],
    prims: ["mix"],
  },
  {
    code: "RR",
    start: 76,
    skip: "R",
    segs: [20, 32],
    chamfer: [0, 0],
    spike: [0, 0],
    prims: ["sphere", "high-seg"],
  },
];

function lerp(a: number, b: number, t: number) {
  return a + (b - a) * t;
}

function buildKits(): Kit[] {
  const out: Kit[] = [];
  for (const band of BANDS) {
    const mids = [...ALPHA].filter((c) => c !== band.skip);
    for (let i = 0; i < 25; i++) {
      const n = band.start + i;
      const t = i / 24;
      const prim = band.prims[i % band.prims.length]!;
      out.push({
        id: `${band.code}${mids[i]}-${String(n).padStart(3, "0")}`,
        band: band.code,
        n,
        segments: Math.round(lerp(band.segs[0], band.segs[1], t)),
        chamfer: Number(lerp(band.chamfer[0], band.chamfer[1], t).toFixed(3)),
        spike: Number(lerp(band.spike[0], band.spike[1], t).toFixed(3)),
        prim,
      });
    }
  }
  return out;
}

export const KITS: Kit[] = buildKits();

const BY_ID = new Map(KITS.map((k) => [k.id, k]));

export function kitById(id: string): Kit {
  return BY_ID.get(id) ?? BY_ID.get(defaultId)!;
}

export function kitsByBand(band: KitBand): Kit[] {
  return KITS.filter((k) => k.band === band);
}
