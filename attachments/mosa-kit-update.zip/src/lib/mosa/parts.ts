/** Slot families from mosa-parts-done.json. L/R merged. Not a kit walk. */

export type PartStatus = "unique" | "folded" | "gap" | "blocked";

export type PartFamily = {
  id: string;
  slots: string[];
  status: PartStatus;
  keep: string | null;
  label: string;
};

export type PartGroup = {
  id: string;
  label: string;
  families: string[];
};

const LABELS: Record<string, string> = {
  helm: "Helm",
  visor: "Visor",
  vfin: "Crest",
  face: "Face",
  ear: "Ear",
  antenna: "Antenna",
  collar: "Collar",
  chestCore: "Chest",
  pec: "Pectoral",
  abdomen: "Abdomen",
  cockpit: "Cockpit",
  pelvis: "Pelvis",
  skirt: "Skirt",
  shoulder: "Shoulder",
  upper: "Upper",
  elbow: "Elbow",
  forearm: "Forearm",
  vambrace: "Vambrace",
  hand: "Hand",
  hip: "Hip",
  thigh: "Thigh",
  knee: "Knee",
  shin: "Shin",
  ankle: "Ankle",
  foot: "Foot",
  pack: "Pack",
  thruster: "Thruster",
  binder: "Binder",
  stabilizer: "Stabilizer",
  weapon: "Weapon",
  shield: "Shield",
  extra: "Extra",
};

export const FAMILIES: PartFamily[] = [
  { id: "helm", slots: ["helm"], status: "unique", keep: "RRE-080", label: LABELS.helm },
  { id: "visor", slots: ["visor"], status: "unique", keep: "RRE-080", label: LABELS.visor },
  { id: "vfin", slots: ["vfin"], status: "unique", keep: "RRE-080", label: LABELS.vfin },
  {
    id: "face",
    slots: ["brow", "eyeL", "eyeR", "nose", "mouth", "jaw", "cheekL", "cheekR", "chin"],
    status: "folded",
    keep: "visor",
    label: LABELS.face,
  },
  { id: "ear", slots: ["earL", "earR"], status: "folded", keep: "helm", label: LABELS.ear },
  {
    id: "antenna",
    slots: ["antennaL", "antennaR"],
    status: "folded",
    keep: "vfin",
    label: LABELS.antenna,
  },
  { id: "collar", slots: ["collar"], status: "unique", keep: "RRE-080", label: LABELS.collar },
  { id: "chestCore", slots: ["chestCore"], status: "unique", keep: "RRE-080", label: LABELS.chestCore },
  { id: "pec", slots: ["pecL", "pecR"], status: "folded", keep: "chestCore", label: LABELS.pec },
  { id: "abdomen", slots: ["abdomen"], status: "folded", keep: "chestCore", label: LABELS.abdomen },
  { id: "cockpit", slots: ["cockpit"], status: "folded", keep: "chestCore", label: LABELS.cockpit },
  { id: "pelvis", slots: ["pelvis"], status: "unique", keep: "RRE-080", label: LABELS.pelvis },
  {
    id: "skirt",
    slots: ["skirtF", "skirtB", "skirtL", "skirtR"],
    status: "folded",
    keep: "pelvis",
    label: LABELS.skirt,
  },
  { id: "shoulder", slots: ["shoulderL", "shoulderR"], status: "unique", keep: "RRE-080", label: LABELS.shoulder },
  { id: "upper", slots: ["upperL", "upperR"], status: "unique", keep: "RRE-080", label: LABELS.upper },
  { id: "elbow", slots: ["elbowL", "elbowR"], status: "unique", keep: "RRE-080", label: LABELS.elbow },
  { id: "forearm", slots: ["forearmL", "forearmR"], status: "folded", keep: "upper", label: LABELS.forearm },
  { id: "vambrace", slots: ["vambraceL", "vambraceR"], status: "folded", keep: "upper", label: LABELS.vambrace },
  { id: "hand", slots: ["handL", "handR"], status: "gap", keep: null, label: LABELS.hand },
  { id: "hip", slots: ["hipL", "hipR"], status: "folded", keep: "pelvis", label: LABELS.hip },
  { id: "thigh", slots: ["thighL", "thighR"], status: "unique", keep: "RRE-080", label: LABELS.thigh },
  { id: "knee", slots: ["kneeL", "kneeR"], status: "folded", keep: "elbow", label: LABELS.knee },
  { id: "shin", slots: ["shinL", "shinR"], status: "folded", keep: "thigh", label: LABELS.shin },
  { id: "ankle", slots: ["ankleL", "ankleR"], status: "folded", keep: "elbow", label: LABELS.ankle },
  { id: "foot", slots: ["footL", "footR"], status: "unique", keep: "RRE-080", label: LABELS.foot },
  { id: "pack", slots: ["pack"], status: "unique", keep: "RRE-080", label: LABELS.pack },
  { id: "thruster", slots: ["thrusterL", "thrusterR"], status: "folded", keep: "pack", label: LABELS.thruster },
  { id: "binder", slots: ["binderL", "binderR"], status: "unique", keep: "RRE-080", label: LABELS.binder },
  { id: "stabilizer", slots: ["stabilizer"], status: "folded", keep: "pack", label: LABELS.stabilizer },
  { id: "weapon", slots: ["weaponL", "weaponR"], status: "gap", keep: null, label: LABELS.weapon },
  { id: "shield", slots: ["shield"], status: "blocked", keep: null, label: LABELS.shield },
  {
    id: "extra",
    slots: ["extra1", "extra2", "extra3", "extra4", "extra5", "extra6", "extra7", "extra8", "extra9", "extra10"],
    status: "unique",
    keep: "slot-type",
    label: LABELS.extra,
  },
];

export const GROUPS: PartGroup[] = [
  { id: "Head", label: "Head", families: ["helm", "visor", "vfin", "face", "ear", "antenna"] },
  { id: "Torso", label: "Torso", families: ["collar", "chestCore", "pec", "abdomen", "cockpit"] },
  { id: "Waist", label: "Waist", families: ["pelvis", "skirt"] },
  { id: "Arm R", label: "Arm R", families: ["shoulder", "upper", "elbow", "forearm", "vambrace", "hand"] },
  { id: "Arm L", label: "Arm L", families: ["shoulder", "upper", "elbow", "forearm", "vambrace", "hand"] },
  { id: "Leg R", label: "Leg R", families: ["hip", "thigh", "knee", "shin", "ankle", "foot"] },
  { id: "Leg L", label: "Leg L", families: ["hip", "thigh", "knee", "shin", "ankle", "foot"] },
  { id: "Back", label: "Back", families: ["pack", "thruster", "binder", "stabilizer"] },
  { id: "Weapons", label: "Weapons", families: ["weapon", "shield"] },
  { id: "Extra", label: "Extra", families: ["extra"] },
];

const FAMILY_BY_ID = new Map(FAMILIES.map((f) => [f.id, f]));

export function familyById(id: string): PartFamily | undefined {
  return FAMILY_BY_ID.get(id);
}

export function groupSide(groupId: string): "L" | "R" | null {
  if (groupId.endsWith(" R")) return "R";
  if (groupId.endsWith(" L")) return "L";
  return null;
}

/** Slots owned by a family inside a hangar group (Arm R → *R only). */
export function slotsFor(groupId: string, familyId: string): string[] {
  const fam = FAMILY_BY_ID.get(familyId);
  if (!fam) return [];
  const side = groupSide(groupId);
  if (!side) return fam.slots;
  const sided = fam.slots.filter((s) => s.endsWith(side));
  return sided.length ? sided : fam.slots;
}

const START_HIDDEN_FAMILIES = new Set(["face", "ear", "antenna", "vfin", "hand", "weapon", "shield"]);

export function defaultHiddenSlots(): Set<string> {
  const hidden = new Set<string>();
  for (const fam of FAMILIES) {
    if (fam.status === "gap" || fam.status === "blocked" || START_HIDDEN_FAMILIES.has(fam.id)) {
      for (const slot of fam.slots) hidden.add(slot);
    }
  }
  return hidden;
}

export function isFamilyVisible(hidden: ReadonlySet<string>, groupId: string, familyId: string): boolean {
  const slots = slotsFor(groupId, familyId);
  if (!slots.length) return false;
  return slots.some((s) => !hidden.has(s));
}

export function toggleFamily(
  hidden: ReadonlySet<string>,
  groupId: string,
  familyId: string,
): Set<string> {
  const next = new Set(hidden);
  const slots = slotsFor(groupId, familyId);
  const on = isFamilyVisible(hidden, groupId, familyId);
  for (const slot of slots) {
    if (on) next.add(slot);
    else next.delete(slot);
  }
  return next;
}
